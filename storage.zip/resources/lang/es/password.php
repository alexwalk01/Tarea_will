<?php

return [
    'reset' => 'Reestablece tu contraseña',
    'sent' => 'Revisa tu bandeja de entrada, te hemos enviado un correo con instrucciones para restablecer tu contraseña.',
    'throttled' => 'Por favor, espera antes de volver a intentarlo.',
    'token' => 'Este token de restablecimiento de contraseña es inválido.',
    'user' => "No podemos encontrar un usuario con ese correo electrónico.",
    'password' => 'Contraseña',
];
