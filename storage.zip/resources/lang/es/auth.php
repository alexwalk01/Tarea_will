<?php

return [
    'login' => 'Iniciar sesión',
    'register' => 'Registrarse',
    'password' => 'Contraseña',  // Aquí agregarías las claves relacionadas con 'password' si no están en 'passwords.php'
    'email' => 'Dirección de correo electrónico',
    'remember' => 'Recordarme',
];
