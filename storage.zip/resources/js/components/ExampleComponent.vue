<template>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">Example Component</div>
            <div class="card-body">
                This is an example component.
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "ExampleComponent",
};
</script>

<style scoped>
.card-header {
    font-weight: bold;
}
</style>
