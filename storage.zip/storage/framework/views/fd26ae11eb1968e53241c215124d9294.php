<?php $__env->startSection('cssLogin'); ?>
    <!-- Importa la hoja de estilo de la sección -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styleLogin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container d-flex align-items-center justify-content-center vh-100">
    <div class="card shadow-lg p-4" style="max-width: 380px; width: 100%; border-radius: 20px; overflow: hidden; background: #ffffff;">

        <div>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>

        <!-- Mensaje de sesión cerrada -->
        <div id="session-message" class="alert alert-warning" style="display: none;">
            Tu sesión ha sido cerrada porque se inició sesión en otro dispositivo.
        </div>

        <div class="text-center mb-4">
            <h3 class="fw-bold text-primary"><?php echo e(__('Bienvenido')); ?></h3>
            <p class="text-muted"><?php echo e(__('Inicia sesión para continuar')); ?></p>
        </div>

        <div class="card-body">
            <?php if(session('message')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <?php echo e(session('message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>


            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="email" class="form-label fw-semibold"><?php echo e(__('Correo Electrónico')); ?></label>
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label fw-semibold"><?php echo e(__('Contraseña')); ?></label>
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg" style="border-radius: 10px; background: #6a11cb; border: none;"><?php echo e(__('Iniciar sesión')); ?></button>
                </div>

                <div class="text-center mt-4">
                    <?php if(Route::has('password.request')): ?>
                        <a class="text-decoration-none text-primary fw-bold" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Mostrar el mensaje de sesión cerrada por 5 segundos
    window.onload = function() {
        var sessionMessage = document.getElementById('session-message');
        if (sessionMessage) {
            sessionMessage.style.display = 'block'; // Mostrar el mensaje
            setTimeout(function() {
                sessionMessage.style.display = 'none'; // Ocultar el mensaje después de 5 segundos
            }, 5000);
        }
    };
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\guill\tarea\Tarea_will\resources\views/auth/login.blade.php ENDPATH**/ ?>